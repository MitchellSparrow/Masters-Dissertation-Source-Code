""" Common Vision Blox DNC module for Python
"""

import cvb as _cvb
import sys as _sys
import os as _os

import _dnc

_mbi_id = _dnc._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

# Classes
Finder = _dnc.Finder
SearchParameters = _dnc.SearchParameters
SearchResult = _dnc.SearchResult
TeachParameters = _dnc.TeachParameters

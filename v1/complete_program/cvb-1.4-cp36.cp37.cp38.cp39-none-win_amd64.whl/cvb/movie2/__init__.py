""" Common Vision Blox Movie recording module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/Movie2/'>Common Vision Blox-Tool Movie</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os







import _movie2

_mbi_id = _movie2._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())



_RecorderPixelFormat = _movie2.RecorderPixelFormat
RecorderPixelFormat =  _movie2.RecorderPixelFormat()

_RecordingEngineType = _movie2.RecordingEngineType
RecordingEngineType =  _movie2.RecordingEngineType()

Recorder = _movie2.Recorder
RecordingSettings = _movie2.RecordingSettings
DirectShowSettings = _movie2.DirectShowSettings
RawVideoSettings = _movie2.RawVideoSettings








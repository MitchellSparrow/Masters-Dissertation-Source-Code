""" Common Vision Blox Polimago module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/Polimago/'>Common Vision Blox-Tool Polimago</a>
"""


import cvb as _cvb
import sys as _sys
import os as _os

import minos as _minos
import sample_database as _sample_database







import _polimago

_mbi_id = _polimago._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())



_ClassificationType = _polimago.ClassificationType
ClassificationType =  _polimago.ClassificationType()

_InvarianceType = _polimago.InvarianceType
InvarianceType =  _polimago.InvarianceType()

SearchResult = _polimago.SearchResult

ClassificationResult = _polimago.ClassificationResult

_InterpolationType = _polimago.InterpolationType
InterpolationType =  _polimago.InterpolationType()

PolimagoFactoryCreatedObject = _polimago.PolimagoFactoryCreatedObject

PredictorBase = _polimago.PredictorBase

PredictorBaseEx = _polimago.PredictorBaseEx

SearchPredictor = _polimago.SearchPredictor

RegressionPredictor = _polimago.RegressionPredictor

ClassificationPredictor = _polimago.ClassificationPredictor

PredictionResult = _polimago.PredictionResult

ConfusionMatrix = _polimago.ConfusionMatrix

TestResultBase = _polimago.TestResultBase

ClassificationTestResult = _polimago.ClassificationTestResult

RegressionTestResult = _polimago.RegressionTestResult

TestResultFactory = _polimago.TestResultFactory

HoldoutTestResultFactory = _polimago.HoldoutTestResultFactory

SampleTestResultFactory = _polimago.SampleTestResultFactory

PredictorFactoryBase = _polimago.PredictorFactoryBase

PredictorFactoryBaseEx = _polimago.PredictorFactoryBaseEx

RegressionPredictorFactory = _polimago.RegressionPredictorFactory

ClassificationPredictorFactory = _polimago.ClassificationPredictorFactory

SearchPredictorFactory = _polimago.SearchPredictorFactory


get_granularity = _polimago.get_granularity


""" Common Vision Blox Spectral module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/Spectral/'>Common Vision Blox-Tool Spectral</a>
"""

import cvb as _cvb
import sys as _sys
import os as _os





import _spectral

_mbi_id = _spectral._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())

# enums
_FieldID =  _spectral.FieldID
FieldID =  _spectral.FieldID()

_FieldType =  _spectral.FieldType
FieldType =  _spectral.FieldType()

_CubeEncoding =  _spectral.CubeEncoding
CubeEncoding =  _spectral.CubeEncoding()

_CubeType =  _spectral.CubeType
CubeType =  _spectral.CubeType()

_NormalizationMethod =  _spectral.NormalizationMethod
NormalizationMethod =  _spectral.NormalizationMethod()

_StdIlluminant =  _spectral.StdIlluminant
StdIlluminant =  _spectral.StdIlluminant()

_StdObserver =  _spectral.StdObserver
StdObserver =  _spectral.StdObserver()

_InterpolationMethod =  _spectral.InterpolationMethod
InterpolationMethod =  _spectral.InterpolationMethod()

_PixelOverflow =  _spectral.PixelOverflow
PixelOverflow =  _spectral.PixelOverflow()

_PixelOverflow =  _spectral.PixelOverflow
PixelOverflow =  _spectral.PixelOverflow()


# classes
MetaData =  _spectral.MetaData
Cube =  _spectral.Cube
WrappedCube =  _spectral.WrappedCube
Interpolator =  _spectral.Interpolator
CubeRange =  _spectral.CubeRange


# functions
normalize = _spectral.normalize
add_cube = _spectral.add_cube
subtract_cube = _spectral.subtract_cube
multiply_cube = _spectral.multiply_cube
divide_cube = _spectral.divide_cube

convert_cube_to_xyz = _spectral.convert_cube_to_xyz
convert_cube_to_lab = _spectral.convert_cube_to_lab
convert_xyz_to_lab = _spectral.convert_xyz_to_lab
convert_lab_to_rgb8 = _spectral.convert_lab_to_rgb8




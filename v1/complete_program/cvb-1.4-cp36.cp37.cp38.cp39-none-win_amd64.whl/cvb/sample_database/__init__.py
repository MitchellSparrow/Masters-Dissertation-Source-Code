""" Common Vision Blox SampleDatabase module for Python
\n\nOnline Manual\n--------\n
\n<a href='http://help.commonvisionblox.com/SampleDatabase/'>Common Vision Blox-Tool SampleDatabase</a>
"""


import cvb as _cvb
import sys as _sys
import os as _os







import _sample_database

_mbi_id = _sample_database._mbi_id

if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())



Fringes = _sample_database.Fringes

SampleListImageDataType = _sample_database.SampleListImageDataType

SampleList = _sample_database.SampleList

_SampleExtractionMode = _sample_database.SampleExtractionMode
SampleExtractionMode =  _sample_database.SampleExtractionMode()

ImageCollection = _sample_database.ImageCollection

SampleImageList = _sample_database.SampleImageList

ImageClassificationLabelInfo = _sample_database.ImageClassificationLabelInfo

ImageClassificationInfoCollection = _sample_database.ImageClassificationInfoCollection

SampleClassificationImageList = _sample_database.SampleClassificationImageList

ImageRegressionLabelInfo = _sample_database.ImageRegressionLabelInfo

ImageRegressionInfoCollection = _sample_database.ImageRegressionInfoCollection

SampleRegressionImageList = _sample_database.SampleRegressionImageList




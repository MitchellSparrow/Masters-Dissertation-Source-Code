""" Common Vision Blox Barcode module for Python"""

import cvb as _cvb
import sys as _sys
import os as _os







import _barcode

_mbi_id = _barcode._mbi_id
 
if _mbi_id() != _cvb._mbi_id():
  raise RuntimeError("module binary interface mismatch\ncvb:\t\t" + _cvb._mbi_id() + "\n" + __name__ + ":\t" + _mbi_id())




# Classes
ReaderConfig = _barcode.ReaderConfig

# Configuration ---------------------------
Codabar =  _barcode.Codabar
Code11 =  _barcode.Code11
Code32 =  _barcode.Code32
Discrete2of5 =  _barcode.Discrete2of5
Ean8 =  _barcode.Ean8
Ean13 =  _barcode.Ean13
FourStateAustralian =  _barcode.FourStateAustralian
FourStateKix =  _barcode.FourStateKix
FourStateRoyalMail =  _barcode.FourStateRoyalMail
FourStateUsps =  _barcode.FourStateUsps
Interleaved2of5 =  _barcode.Interleaved2of5
MicroPdf417 =  _barcode.MicroPdf417
MsiPlessey =  _barcode.MsiPlessey
PharmaCode =  _barcode.PharmaCode
Planet =  _barcode.Planet
Postnet =  _barcode.Postnet
Rss =  _barcode.Rss
UpcA =  _barcode.UpcA
UpcE =  _barcode.UpcE
Pdf417 =  _barcode.Pdf417
DataMatrix =  _barcode.DataMatrix
DataMatrixGrading =  _barcode.DataMatrixGrading
Qr =  _barcode.Qr
QrGrading =  _barcode.QrGrading
SonyCode =  _barcode.SonyCode
Code128 =  _barcode.Code128
Code39 =  _barcode.Code39
Code93 =  _barcode.Code93
BarcodeGrading =  _barcode.BarcodeGrading

ConfigBase =  _barcode.ConfigBase
ReaderConfigBase =  _barcode.ReaderConfigBase
# ReaderWithQuietzoneConfigBase =  _barcode.ReaderWithQuietzoneConfigBase
# ReaderCommon1DConfigBase =  _barcode.ReaderCommon1DConfigBase
# ReaderWithBooleanCheckDigitConfigBase =  _barcode.ReaderWithBooleanCheckDigitConfigBase
# ReaderWithTransmitStartStopConfigBase =  _barcode.ReaderWithTransmitStartStopConfigBase
# ReaderEanUpcConfigBase =  _barcode.ReaderEanUpcConfigBase
# ReaderFourStateConfigBase =  _barcode.ReaderFourStateConfigBase
# ReaderPlanetPostnetConfigBase =  _barcode.ReaderPlanetPostnetConfigBase
# Reader2DConfigBase =  _barcode.Reader2DConfigBase
# Reader2DWithQuietzoneConfigBase =  _barcode.Reader2DWithQuietzoneConfigBase
# GraderConfigBase =  _barcode.GraderConfigBase
# Grader2DConfigBase =  _barcode.Grader2DConfigBase
  

# Results ---------------------------
ReadResult = _barcode.ReadResult
ReadResult1D =  _barcode.ReadResult1D
ReadResultUpcE =  _barcode.ReadResultUpcE
ReadResultSonyCode =  _barcode.ReadResultSonyCode
ReadResultCode128 =  _barcode.ReadResultCode128
ReadResultCode39Code93 =  _barcode.ReadResultCode39Code93
ReadResultPdf417 =  _barcode.ReadResultPdf417
ReadResultDataMatrix =  _barcode.ReadResultDataMatrix
ReadResultQr =  _barcode.ReadResultQr

# ReadResult2D =  _barcode.ReadResult2D
GradeResult2DBase =  _barcode.GradeResult2DBase

# GradeResults ---------------------------
GradeResultBase =  _barcode.GradeResultBase
GradeResult1D =  _barcode.GradeResult1D
GradeResultDataMatrix =  _barcode.GradeResultDataMatrix
GradeResultQr =  _barcode.GradeResultQr

# Enums ---------------------------
_Readout =  _barcode.Readout
Readout =  _barcode.Readout()
_ReaderInitialization =  _barcode.ReaderInitialization
ReaderInitialization =  _barcode.ReaderInitialization()
_Symbology =  _barcode.Symbology
Symbology =  _barcode.Symbology()
_MsiPlesseyCheckDigit =  _barcode.MsiPlesseyCheckDigit
MsiPlesseyCheckDigit =  _barcode.MsiPlesseyCheckDigit()
_Code11CheckDigit =  _barcode.Code11CheckDigit
Code11CheckDigit =  _barcode.Code11CheckDigit()
_CodeOrientation =  _barcode.CodeOrientation
CodeOrientation =  _barcode.CodeOrientation()
_FourStateAustralianLevels =  _barcode.FourStateAustralianLevels
FourStateAustralianLevels =  _barcode.FourStateAustralianLevels()
_FourStateLsb =  _barcode.FourStateLsb
FourStateLsb =  _barcode.FourStateLsb()
_PlanetLevels =  _barcode.PlanetLevels
PlanetLevels =  _barcode.PlanetLevels()
_PostnetLevels =  _barcode.PostnetLevels
PostnetLevels =  _barcode.PostnetLevels()
_PharmaCodeRunDirection =  _barcode.PharmaCodeRunDirection
PharmaCodeRunDirection =  _barcode.PharmaCodeRunDirection()
_PharmaCodeTolerance =  _barcode.PharmaCodeTolerance
PharmaCodeTolerance =  _barcode.PharmaCodeTolerance()
_DataMatrixLevels =  _barcode.DataMatrixLevels
DataMatrixLevels =  _barcode.DataMatrixLevels()
_DataMatrixFormats =  _barcode.DataMatrixFormats
DataMatrixFormats =  _barcode.DataMatrixFormats()
_DataMatrixSubType =  _barcode.DataMatrixSubType
DataMatrixSubType =  _barcode.DataMatrixSubType()
_PharmaCodeSkew =  _barcode.PharmaCodeSkew
PharmaCodeSkew =  _barcode.PharmaCodeSkew()
_PharmaCode2DDisposition =  _barcode.PharmaCode2DDisposition
PharmaCode2DDisposition =  _barcode.PharmaCode2DDisposition()
_Pdf417Levels =  _barcode.Pdf417Levels
Pdf417Levels =  _barcode.Pdf417Levels()
_QrSubType =  _barcode.QrSubType
QrSubType =  _barcode.QrSubType()
_RssTypes =  _barcode.RssTypes
RssTypes =  _barcode.RssTypes()
_RssComposition =  _barcode.RssComposition
RssComposition =  _barcode.RssComposition()
_DecodeResult =  _barcode.DecodeResult
DecodeResult =  _barcode.DecodeResult()
_EccLevelQr =  _barcode.EccLevelQr
EccLevelQr =  _barcode.EccLevelQr()
_Code128SubType =  _barcode.Code128SubType
Code128SubType =  _barcode.Code128SubType()
_QrMasking =  _barcode.QrMasking
QrMasking =  _barcode.QrMasking()
_GradeResult1DInfo =  _barcode.GradeResult1DInfo
GradeResult1DInfo =  _barcode.GradeResult1DInfo()


# functions
decode = _barcode.decode
teach_dotted_data_matrix = _barcode.teach_dotted_data_matrix